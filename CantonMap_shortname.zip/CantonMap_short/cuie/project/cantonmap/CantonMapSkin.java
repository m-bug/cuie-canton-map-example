package cuie.project.cantonmap;

import cuie.project.cantonmap.components.Autosuggestion;
import cuie.project.cantonmap.components.CantonMap;
import cuie.project.cantonmap.model.State;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.geometry.Point2D;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.SkinBase;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.stage.Popup;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/*
 * This class contains the skin of the custom
 *  control canton-map.
 *
 */
class CantonMapSkin extends SkinBase<CantonMapControl> {

    // stylesheet
    private static final String STYLE_CSS = "style.css";

    // Icons
    private static final String ANGLE_DOWN = "\uf107";
    private static final String ANGLE_UP = "\uf106";
    private static final int ICON_SIZE = 9;
    private static final int IMG_OFFSET = 3;

    // all parts
    private TextField editableNode;
    private Label label;
    private Label readOnlyLabel;
    private Popup popupMap;
    private Popup popupAutosuggestion;
    private Autosuggestion autosuggestion;
    private Pane cantonMapPane;
    private Button chooserButton;
    private StackPane drawingPane;

    /**
     * Properties
     */
    private final BooleanProperty mandatory = new SimpleBooleanProperty();

    CantonMapSkin(CantonMapControl control) {
        super(control);
        initializeSelf();
        initializeParts();
        layoutParts();
        setupAnimations();
        setupEventHandlers();
        setupValueChangeListeners();
        setupBindings();
    }

    /**
     * loads fonts (including fontawesome to use icons) & stylesheets
     */
    private void initializeSelf() {
        getSkinnable().loadFonts("/fonts/fontawesome-webfont.ttf");
        getSkinnable().addStylesheetFiles(STYLE_CSS);
    }

    private void initializeParts() {
        editableNode = new TextField();
        editableNode.getStyleClass().add("canton-text-field");
        editableNode.getStyleClass().add("underlined");

        label = new Label();
        label.getStyleClass().add("caption-label");

        readOnlyLabel = new Label(getSkinnable().getReadOnlyCaption());
        readOnlyLabel.getStyleClass().add("read-only-label");
        //readOnlyLabel.getStyleClass().add("underlined");

        chooserButton = new Button(ANGLE_DOWN);
        chooserButton.getStyleClass().add("chooser-button");
        chooserButton.getStyleClass().add("underlined");

        cantonMapPane = new CantonMap(getSkinnable());

        popupMap = new Popup();
        popupMap.getContent().addAll(cantonMapPane);
        popupMap.setAutoHide(true);
        popupMap.setAutoFix(true);

        autosuggestion = new Autosuggestion();

        popupAutosuggestion = new Popup();
        popupAutosuggestion.getContent().addAll(autosuggestion);
        popupAutosuggestion.setAutoHide(true);
        popupAutosuggestion.setAutoFix(true);

        drawingPane = new StackPane();
        drawingPane.getStyleClass().add("drawing-pane");
    }

    private void layoutParts() {
        label.setAlignment(Pos.CENTER_LEFT);
        var box = new HBox(label, editableNode, readOnlyLabel, chooserButton);
        getChildren().add(box);
    }

    private void setupAnimations() {

    }

    private void setupValueChangeListeners() {
        getSkinnable().autoCompleteTextsProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue.size() == 0) {
                popupAutosuggestion.hide();
                return;
            }

            Point2D location = editableNode.localToScreen(0, 16);

            popupAutosuggestion.setX(location.getX());
            popupAutosuggestion.setY(location.getY());


            autosuggestion.getChildren().clear();

            List<Label> labels = new ArrayList<>();
            for (var suggestion : getSkinnable().autoCompleteTextsProperty()) {
                var label = new Label(suggestion);
                label.setPrefWidth(editableNode.getWidth() + chooserButton.getWidth() - 7);

                label.setOnMouseClicked(timeslot -> {
                    getSkinnable().setText(getCantonFromLabel(label));
                    popupAutosuggestion.hide();
                });
                labels.add(label);
            }
            autosuggestion.getChildren().setAll(labels);
            popupAutosuggestion.show(editableNode.getScene().getWindow());
        });

        getSkinnable().textProperty().addListener((observable, oldValue, newValue) -> {
            if (autosuggestion.getChildren().size() > 0 && focusedChild().isEmpty()) focusFirst();
            popupMap.hide();

        });

        mandatory.addListener((observable, oldValue, newValue) -> {
            if (newValue) {
                setMandatoryBackground();
            } else {
                removeBackground();
            }
        });

    }

    private void setupEventHandlers() {
        chooserButton.setOnAction(event -> {
            if (popupMap.isShowing()) {
                popupMap.hide();
            } else {
                popupMap.show(editableNode.getScene().getWindow());
            }
        });

        popupMap.setOnHidden(event -> chooserButton.setText(ANGLE_DOWN));

        popupMap.setOnShown(event -> {
            chooserButton.setText(ANGLE_UP);
            Point2D location = editableNode.localToScreen(editableNode.getWidth() + chooserButton.getWidth() - cantonMapPane.getWidth(),
                    editableNode.getHeight() - 6);

            popupMap.setX(location.getX());
            popupMap.setY(location.getY());
        });

        editableNode.setOnAction(event -> {
            var focused = focusedChild();
            if (focused.isPresent()) {
                var label = (Label) focused.get();
                getSkinnable().setText(getCantonFromLabel(label));
                editableNode.getParent().requestFocus();
                popupAutosuggestion.hide();
            }
            event.consume();
        });

        editableNode.addEventFilter(KeyEvent.KEY_PRESSED, event -> {
            switch (event.getCode()) {
                case ESCAPE: {
                    getSkinnable().reset();
                    event.consume();
                    break;
                }

                case UP: {
                    if (autosuggestion.getChildren().size() != 0) {
                        updateAutosuggestionSelection(true);
                        event.consume();
                    }
                    break;
                }

                case DOWN: {
                    if (autosuggestion.getChildren().size() != 0) {
                        updateAutosuggestionSelection(false);
                        event.consume();
                    }
                    break;
                }

                case TAB: {
                    if (autosuggestion.getChildren().size() != 0) {
                        updateAutosuggestionSelection(event.isShiftDown());
                        event.consume();
                    }
                    break;
                }

            }
        });
    }

    public void setMandatoryBackground() {
        editableNode.setStyle("-fx-background-image: url('" + State.REQUIRED.imageView.getImage().getUrl() + "'); " +
                "-fx-background-position: left " + IMG_OFFSET + " top " + IMG_OFFSET + ";" +
                "-fx-background-repeat: no-repeat;" +
                "-fx-background-size:" + ICON_SIZE + " " + ICON_SIZE + ";" +
                "");
    }

    public void removeBackground() {
        editableNode.setStyle("");
    }

    private String getCantonFromLabel(Label label) {
        return label.getText().split("\\(")[1].split("\\)")[0].strip();
    }

    private Optional<Node> focusedChild() {
        return autosuggestion.getChildren().stream().filter(Node::isFocused).findFirst();
    }

    private void focusNext() {
        var focused = focusedChild();

        if (focused.isPresent()) {
            int id = autosuggestion.getChildren().indexOf(focused.get());
            int next_id = id + 1;
            if (next_id >= autosuggestion.getChildren().size()) next_id = 0;
            autosuggestion.getChildren().get(next_id).requestFocus();
        }
    }

    private void focusPrevious() {
        var focused = focusedChild();

        if (focused.isPresent()) {
            int id = autosuggestion.getChildren().indexOf(focused.get());
            int next_id = id - 1;
            if (next_id < 0) next_id = autosuggestion.getChildren().size() - 1;
            autosuggestion.getChildren().get(next_id).requestFocus();
        }
    }

    private void focusFirst() {
        autosuggestion.getChildren().get(0).requestFocus();
    }

    private void updateAutosuggestionSelection(boolean reversed) {
        var focused = focusedChild();

        if (focused.isEmpty()) {
            focusFirst();
        } else {
            if (reversed) {
                focusPrevious();
            } else {
                focusNext();
            }
        }
    }

/*

        getSkinnable().textProperty().addListener((observable, oldValue, newValue) -> {
            editableNode.setText(newValue);
        });
        editableNode.textProperty().addListener((observable, oldValue, newValue) -> {
            getSkinnable().textProperty().setValue(newValue);
        });
*/

    private void setupBindings() {
        // editableNode.promptTextProperty().bind(getSkinnable().previewTextProperty());

        editableNode.textProperty().bindBidirectional(getSkinnable().textProperty());
        label.textProperty().bind(getSkinnable().labelProperty());

        editableNode.visibleProperty().bind(getSkinnable().readOnlyProperty().not());
        editableNode.managedProperty().bind(editableNode.visibleProperty());

        chooserButton.visibleProperty().bind(getSkinnable().readOnlyProperty().not());
        chooserButton.managedProperty().bind(chooserButton.visibleProperty());

        readOnlyLabel.visibleProperty().bind(getSkinnable().readOnlyProperty());
        readOnlyLabel.managedProperty().bind(readOnlyLabel.visibleProperty());

        readOnlyLabel.textProperty().bindBidirectional(getSkinnable().textProperty());

        mandatory.bind(getSkinnable().mandatoryProperty());
    }

    /**
     * Getter and Setter
     */
    public boolean isMandatory() {
        return mandatory.get();
    }

    public void setMandatory(boolean mandatory) {
        this.mandatory.set(mandatory);
    }

    public BooleanProperty mandatoryProperty() {
        return mandatory;
    }
}
