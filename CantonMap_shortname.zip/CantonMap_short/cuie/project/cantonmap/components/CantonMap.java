package cuie.project.cantonmap.components;

import cuie.project.cantonmap.CantonMapControl;
import cuie.project.cantonmap.model.Canton;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.charset.UnsupportedCharsetException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/*
 * This class contains the logic of
 * the graphical Swiss map.
 */
public class CantonMap extends GridPane {

    public static final int N_COLUMNS = 15;
    public static final int N_ROWS = 10;
    private static final String STYLE_CSS = "CantonMap.css";
    private static final List<Canton> cantons = new ArrayList<>();

    static {
        loadCantonData();
    }

    private final CantonMapControl cantonMapControl;
    // SWISS MAP LAYOUT
    //". . . . BS BS . . . . SH SH . . ."
    //". . . . BS BS . . . . SH SH . . ."
    //". . . JU JU BL BL AG AG ZH ZH TG TG AR AR"
    //". . . JU JU BL BL AG AG ZH ZH TG TG AR AR"
    //". . NE NE SO SO LU LU ZG ZG SG SG AI AI ."
    //". . NE NE SO SO LU LU ZG ZG SG SG AI AI ."
    //". VD VD FR FR BE BE NW NW SZ SZ GL GL GR GR"
    //". VD VD FR FR BE BE NW NW SZ SZ GL GL GR GR"
    //"GE GE . . VS VS . . OW OW UR UR . . ."
    //"GE GE . . VS VS . .OW OW UR UR . . ."
    //".  .  .  .  . . . . . .TI TI . . ."
    //"AS AS AS AS . . . . . .TI TI . . ."

    public CantonMap(CantonMapControl cantonMapControl) {
        this.cantonMapControl = cantonMapControl;
        initializeSelf();
        initializeParts();
        layoutParts();
        setupBindings();
    }

    /**
     * Logic
     */
    public static boolean isCantonName(String input) {
        return getCantons().stream()
                .anyMatch(c -> c.getName().equalsIgnoreCase(input));
    }

    public static boolean isCantonAbbreviation(String input) {
        return getCantons().stream()
                .anyMatch(c -> c.getAbbreviation().equals(input));
    }

    public static Optional<Canton> canBeExtendedTo(String input) {
        if (input == null || "".equals(input)) {
            return Optional.empty();
        }
        return getCantons().stream()
                .filter(c -> c.getName().toLowerCase().startsWith(input.toLowerCase()) || c.getAbbreviation().toLowerCase().startsWith(input.toLowerCase())).findFirst();
    }

    private static void loadCantonData() {
        var inputStream = CantonMap.class.getClassLoader().getResourceAsStream("canton_data.txt");
        List<String> lines = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.UTF_8))
            .lines().collect(Collectors.toList());

        var cantonData = lines.stream().map(line -> {
            var el = line.split(",");
            return new Canton(Integer.parseInt(el[0]), Integer.parseInt(el[1]), el[2], el[3]);
        });
        cantons.addAll(cantonData.collect(Collectors.toList()));
        cantons.sort(Comparator.comparing(Canton::getName));
    }

    /**
     * Getter and Setter
     */
    public static List<Canton> getCantons() {
        return cantons;
    }

    /**
     * Setup
     */
    private void initializeSelf() {
        String stylesheet = getClass().getResource(STYLE_CSS).toExternalForm();
        getStylesheets().add(stylesheet);
        getStyleClass().add("canton-map");

        for (int i = 0; i < N_COLUMNS; i++) {
            getColumnConstraints().add(new ColumnConstraints(20));
        }
        for (int i = 0; i < N_ROWS; i++) {
            getRowConstraints().add(new RowConstraints(20));
        }
    }

    private void initializeParts() {
        for (var canton : cantons) {
            var cantonBox = new CantonBox(this, canton.getAbbreviation());
            add(cantonBox, canton.getColumn(), canton.getRow(), 2, 2);
            cantonBox.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
        }
    }

    private void layoutParts() {
    }

    private void setupBindings() {
    }

    public void updateSelection(CantonBox cantonBox) {
        var cantonAbbreviation = cantonBox.getCantonText().getText();
        var canton = cantons.stream().filter(c -> c.getAbbreviation().equals(cantonAbbreviation)).findFirst().get();
        cantonMapControl.textProperty().setValue(canton.getAbbreviation());
    }
}
