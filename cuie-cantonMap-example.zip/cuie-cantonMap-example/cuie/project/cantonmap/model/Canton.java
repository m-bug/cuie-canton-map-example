package cuie.project.cantonmap.model;

public class Canton {
    private final int column;
    private final int row;
    private final String name;
    private final String abbreviation;

    public Canton(int column, int row, String abbreviation, String name) {
        this.column = column;
        this.row = row;
        this.name = name;
        this.abbreviation = abbreviation;
    }

    public int getColumn() {
        return column;
    }

    public int getRow() {
        return row;
    }

    public String getName() {
        return name;
    }

    public String getAbbreviation() {
        return abbreviation;
    }
}
