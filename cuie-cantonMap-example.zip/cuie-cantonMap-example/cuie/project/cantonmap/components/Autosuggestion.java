package cuie.project.cantonmap.components;

import javafx.scene.layout.VBox;

public class Autosuggestion extends VBox {
    private static final String STYLE_CSS = "Autosuggestion.css";

    public Autosuggestion() {
        initializeSelf();
        initializeParts();
        layoutParts();
        setupBindings();
    }

    private void initializeSelf() {
        String stylesheet = getClass().getResource(STYLE_CSS).toExternalForm();
        getStylesheets().add(stylesheet);

        getStyleClass().add("autosuggestion");
    }

    private void initializeParts() {
    }

    private void layoutParts() {
        getChildren().addAll();
    }

    private void setupBindings() {
    }
}
