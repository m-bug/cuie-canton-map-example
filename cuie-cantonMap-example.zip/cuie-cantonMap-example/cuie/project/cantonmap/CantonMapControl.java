package cuie.project.cantonmap;

import cuie.project.cantonmap.components.CantonMap;
import javafx.beans.property.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.css.PseudoClass;
import javafx.scene.control.Control;
import javafx.scene.control.Skin;
import javafx.scene.text.Font;

import java.util.Optional;
import java.util.stream.Collectors;

/**
 * The custom control CantonMap can be used to implement
 * a text field for selecting a canton of Switzerland.
 * On the one hand, it supports the user with a graphical selection,
 * by displaying a map of Switzerland with all cantons.
 * On the other hand, also by text input, so that the user is
 * made suggestions in a dropdown depending on the input.
 *
 * @author Tobias Kunz
 * @author Marc Bugmann
 */
public class CantonMapControl extends Control {

    /**
     * Pseudo classes
     */
    private static final PseudoClass MANDATORY_CLASS = PseudoClass.getPseudoClass("mandatory");
    private static final PseudoClass INVALID_CLASS = PseudoClass.getPseudoClass("invalid");
    private static final PseudoClass CONVERTIBLE_CLASS = PseudoClass.getPseudoClass("convertible");

    /**
     * Properties
     */
    private final StringProperty text = new SimpleStringProperty("");
    private final StringProperty label = new SimpleStringProperty();
    private final StringProperty readOnlyCaption = new SimpleStringProperty();
    private final ListProperty<String> autoCompleteTexts = new SimpleListProperty<>();

    private final BooleanProperty mandatory = new SimpleBooleanProperty() {
        @Override
        protected void invalidated() {
            super.invalidated();
            pseudoClassStateChanged(MANDATORY_CLASS, get());
        }
    };

    private final BooleanProperty invalid = new SimpleBooleanProperty(false) {
        @Override
        protected void invalidated() {
            super.invalidated();
            pseudoClassStateChanged(INVALID_CLASS, get());
        }
    };

    private final BooleanProperty convertible = new SimpleBooleanProperty(false) {
        @Override
        protected void invalidated() {
            super.invalidated();
            pseudoClassStateChanged(CONVERTIBLE_CLASS, get());
        }
    };

    private final BooleanProperty readOnly = new SimpleBooleanProperty();
    private final StringProperty errorMessage = new SimpleStringProperty();

    /**
     * Ctor
     */
    public CantonMapControl() {
        initializeSelf();
        addValueChangeListener();
    }

    private void initializeSelf() {
        getStyleClass().add("canton-map");
        updateState(text.get());
    }

    private void updateState(String userInput){
        if (CantonMap.isCantonName(userInput)) {
            setInvalid(false);
            setConvertible(false);
        } else if (CantonMap.isCantonAbbreviation(userInput)) {
            setInvalid(true);
            setConvertible(true);
        } else {
            setInvalid(true);
            var canton = CantonMap.canBeExtendedTo(userInput);
            setConvertible(canton.isPresent());
        }
    }

    private void addValueChangeListener() {
        text.addListener((observable, oldValue, userInput) -> {
            updateState(userInput);
            updateAutoCompleteList();
        });
    }

    public void loadFonts(String... font) {
        for (String f : font) {
            Font.loadFont(getClass().getResourceAsStream(f), 0);
        }
    }

    public void addStylesheetFiles(String... stylesheetFile) {
        for (String file : stylesheetFile) {
            String stylesheet = getClass().getResource(file).toExternalForm();
            getStylesheets().add(stylesheet);
        }
    }

    /**
     * Skin
     */
    @Override
    protected Skin<?> createDefaultSkin() {
        return new CantonMapSkin(this);
    }

    /**
     * Logic
     */
    private void updateAutoCompleteList() {
        if (CantonMap.isCantonName(text.get()) || text.getValue().length() == 0) {
            autoCompleteTexts.clear();
        } else {
            var list = CantonMap.getCantons().stream()
                    .filter(
                            c -> c.getName().toLowerCase().startsWith(text.get().toLowerCase())
                                    || c.getAbbreviation().equalsIgnoreCase(text.get().toLowerCase()))
                    .collect(Collectors.toList());
            var names = list.stream().map(c -> c.getName() + " (" + c.getAbbreviation() + ")").collect(Collectors.toList());

            autoCompleteTexts.set(FXCollections.observableArrayList(names));
        }
    }

    public void reset() {
        text.setValue("");
    }

    public void decrease() {
        var id = getIndexOfCurrentText();
        id.ifPresentOrElse((index) -> this.setIndex(index - 1), () -> this.setIndex(0));
    }

    public void increase() {
        var id = getIndexOfCurrentText();
        id.ifPresentOrElse((index) -> this.setIndex(index + 1), () -> this.setIndex(0));
    }

    private Optional<Integer> getIndexOfCurrentText() {
        var canton = CantonMap.getCantons().stream()
                .filter(c -> c.getAbbreviation().equals(text.getValue()) ||
                        c.getName().equals(text.getValue())).findFirst();

        return canton.map(c -> CantonMap.getCantons().indexOf(c));
    }

    public void setIndex(int newIndex) {
        if (newIndex < 0) newIndex = CantonMap.getCantons().size() + newIndex;
        if (newIndex >= CantonMap.getCantons().size())
            newIndex = newIndex % CantonMap.getCantons().size();
        setText(CantonMap.getCantons().get(newIndex).getName());
    }

    public void convert() {
        var canton = CantonMap.canBeExtendedTo(text.get());
        canton.ifPresent(value -> text.setValue(value.getName()));
    }

    /**
     * Getter and Setter
     */
    public String getText() {
        return text.get();
    }

    public void setText(String text) {
        this.text.set(text);
    }

    public StringProperty textProperty() {
        return text;
    }

    public boolean isReadOnly() {
        return readOnly.get();
    }

    public void setReadOnly(boolean readOnly) {
        this.readOnly.set(readOnly);
    }

    public BooleanProperty readOnlyProperty() {
        return readOnly;
    }

    public boolean isMandatory() {
        return mandatory.get();
    }

    public void setMandatory(boolean mandatory) {
        this.mandatory.set(mandatory);
    }

    public BooleanProperty mandatoryProperty() {
        return mandatory;
    }

    public String getLabel() {
        return label.get();
    }

    public void setLabel(String label) {
        this.label.set(label);
    }

    public StringProperty labelProperty() {
        return label;
    }

    public boolean getInvalid() {
        return invalid.get();
    }

    public BooleanProperty invalidProperty() {
        return invalid;
    }

    public String getErrorMessage() {
        return errorMessage.get();
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage.set(errorMessage);
    }

    public StringProperty errorMessageProperty() {
        return errorMessage;
    }

    public boolean isInvalid() {
        return invalid.get();
    }

    public void setInvalid(boolean invalid) {
        this.invalid.set(invalid);
    }

    public void setConvertible(boolean convertible) {
        this.convertible.set(convertible);
    }

    public ObservableList<String> getAutoCompleteTexts() {
        return autoCompleteTexts.get();
    }

    public void setAutoCompleteTexts(ObservableList<String> autoCompleteTexts) {
        this.autoCompleteTexts.set(autoCompleteTexts);
    }

    public ListProperty<String> autoCompleteTextsProperty() {
        return autoCompleteTexts;
    }

    public String getReadOnlyCaption() {
        return readOnlyCaption.get();
    }

    public StringProperty readOnlyCaptionProperty() {
        return readOnlyCaption;
    }

    public void setReadOnlyCaption(String readOnlyCaption) {
        this.readOnlyCaption.set(readOnlyCaption);
    }
}
