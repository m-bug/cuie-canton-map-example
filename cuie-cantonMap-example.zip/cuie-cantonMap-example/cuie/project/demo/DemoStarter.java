package cuie.project.demo;

import fr.brouillard.oss.cssfx.CSSFX;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Region;
import javafx.stage.Stage;
import org.scenicview.ScenicView;

public class DemoStarter extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        PresentationModel model = new PresentationModel();
        Region rootPanel = new DemoPane(model);

        Scene scene = new Scene(rootPanel);

        primaryStage.setTitle("CantonMapControl Demo");
        primaryStage.setScene(scene);

        primaryStage.show();
        CSSFX.start();
/*
        ScenicView.show(scene);
*/
    }
}
