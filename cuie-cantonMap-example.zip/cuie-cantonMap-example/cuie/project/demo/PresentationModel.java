package cuie.project.demo;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class PresentationModel {
    private final StringProperty cantonText = new SimpleStringProperty("");
    private final StringProperty cantonLabel = new SimpleStringProperty("Canton");
    private final BooleanProperty age_readOnly = new SimpleBooleanProperty(false);
    private final BooleanProperty age_mandatory = new SimpleBooleanProperty(true);

    public String getCantonText() {
        return cantonText.get();
    }

    public void setCantonText(String cantonText) {
        this.cantonText.set(cantonText);
    }

    public StringProperty cantonTextProperty() {
        return cantonText;
    }

    public String getCantonLabel() {
        return cantonLabel.get();
    }

    public void setCantonLabel(String cantonLabel) {
        this.cantonLabel.set(cantonLabel);
    }

    public StringProperty cantonLabelProperty() {
        return cantonLabel;
    }

    public boolean isAge_readOnly() {
        return age_readOnly.get();
    }

    public void setAge_readOnly(boolean age_readOnly) {
        this.age_readOnly.set(age_readOnly);
    }

    public BooleanProperty age_readOnlyProperty() {
        return age_readOnly;
    }

    public boolean isAge_mandatory() {
        return age_mandatory.get();
    }

    public void setAge_mandatory(boolean age_mandatory) {
        this.age_mandatory.set(age_mandatory);
    }

    public BooleanProperty age_mandatoryProperty() {
        return age_mandatory;
    }
}
