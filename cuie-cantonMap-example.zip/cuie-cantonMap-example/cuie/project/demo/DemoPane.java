package cuie.project.demo;

import cuie.project.cantonmap.CantonMapControl;
import javafx.geometry.Insets;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;

class DemoPane extends BorderPane {
    private final PresentationModel model;
    private CantonMapControl cantonMapControl;
    private TextField textField;
    private CheckBox readOnlyBox;
    private CheckBox mandatoryBox;
    private TextField labelField;

    DemoPane(PresentationModel model) {
        this.model = model;

        initializeControls();
        layoutControls();
        setupValueChangeListeners();
        setupBindings();
    }

    private void initializeControls() {
        setPadding(new Insets(10));

        cantonMapControl = new CantonMapControl();


        textField = new TextField();

        readOnlyBox = new CheckBox();
        readOnlyBox.setSelected(false);

        mandatoryBox = new CheckBox();
        mandatoryBox.setSelected(true);

        labelField = new TextField();
    }

    private void layoutControls() {
        setCenter(cantonMapControl);
        VBox box = new VBox(10,
                new Label("Business Control Properties"),
                new Label("Text (canton)"), textField,
                new Label("readOnly"), readOnlyBox,
                new Label("mandatory"), mandatoryBox,
                new Label("Label"), labelField);
        box.setPadding(new Insets(10));
        box.setSpacing(10);
        setRight(box);
    }

    private void setupValueChangeListeners() {
    }

    private void setupBindings() {
        textField.textProperty().bindBidirectional(model.cantonTextProperty());
        labelField.textProperty().bindBidirectional(model.cantonLabelProperty());

        readOnlyBox.selectedProperty().bindBidirectional(model.age_readOnlyProperty());
        mandatoryBox.selectedProperty().bindBidirectional(model.age_mandatoryProperty());

        cantonMapControl.textProperty().bindBidirectional(model.cantonTextProperty());
        cantonMapControl.labelProperty().bind(model.cantonLabelProperty());
        cantonMapControl.readOnlyProperty().bind(model.age_readOnlyProperty());
        cantonMapControl.mandatoryProperty().bind(model.age_mandatoryProperty());
    }

}
