package cuie.project.demo;

import cuie.project.cantonmap.CantonMapControl;
import javafx.geometry.Insets;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;

class DemoPane2 extends VBox {
    private final PresentationModel model;
    private CantonMapControl cantonMapControl;
    private TextField textField;
    private CheckBox readOnlyBox;
    private CheckBox mandatoryBox;

    DemoPane2(PresentationModel model) {
        this.model = model;

        initializeControls();
        layoutControls();
        setupValueChangeListeners();
        setupBindings();
    }

    private void initializeControls() {
        setPadding(new Insets(10));
        setSpacing(10);

        cantonMapControl = new CantonMapControl();
//        var customControl = new HBox(new Label("Kanton"), cantonMapControl);
        var box1 = new BorderPane();
        box1.setLeft(new Label("Kanton"));
        box1.setRight(cantonMapControl);

        var box2 = new BorderPane();
        box2.setLeft(new Label("Kanton"));
        box2.setRight(new TextField());

        getChildren().addAll(box1, box2);
    }

    private void layoutControls() {
    }

    private void setupValueChangeListeners() {
    }

    private void setupBindings() {
        cantonMapControl.textProperty().bindBidirectional(model.cantonTextProperty());
        cantonMapControl.readOnlyProperty().bind(model.age_readOnlyProperty());
        cantonMapControl.mandatoryProperty().bind(model.age_mandatoryProperty());
    }

}
