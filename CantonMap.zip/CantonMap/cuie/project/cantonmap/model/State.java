package cuie.project.cantonmap.model;

import cuie.project.cantonmap.CantonMapControl;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.util.Objects;

public enum State {
    REQUIRED("Required", "mandatory.png");

    public final String text;

    public final ImageView imageView;

    State(final String text, final String file) {
        this.text = text;
        String url = Objects.requireNonNull(CantonMapControl.class.getResource("icons/" + file)).toExternalForm();
        this.imageView = new ImageView(new Image(url, 16, 16, true, false));
    }
}

