package cuie.project.cantonmap;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/*
    Test pm for oop2 students ;-)
    Usage: (inside your oop2 code, use following line to bind this pm to cantonMapControl)

    var cantonMapControl = new CantonMapControl();
    var pm = new PresentationModel();

    cantonMapControl.textProperty().bindBidirectional(pm.cantonTextProperty());
 */
public class PresentationModel {
    private final StringProperty cantonTextProperty = new SimpleStringProperty("");

    public String getCantonTextProperty() {
        return cantonTextProperty.get();
    }

    public StringProperty cantonTextProperty() {
        return cantonTextProperty;
    }

    public void setCantonTextProperty(String cantonTextProperty) {
        this.cantonTextProperty.set(cantonTextProperty);
    }
}
